// ZEN TRADE AI starter backend. Node 20+
const express=require('express');
const {WebSocket}=require('ws');
const path=require('path');
const app=express();app.use(express.json({limit:'32kb'}));app.use(express.static(path.join(__dirname,'public')));
let deriv=null, ticks=[], balance=null,currency='',markets=[],subscriptions=new Set(),lastErr='';
const API='https://api.derivws.com';
function send(obj){if(deriv&&deriv.readyState===WebSocket.OPEN)deriv.send(JSON.stringify(obj))}
app.post('/api/connect',async(req,res)=>{
 try{
  const {appId,token,accountId,mode}=req.body||{};
  if(!appId||!token||!accountId)throw Error('Enter App ID, PAT and account ID.');
  if(mode!=='demo')throw Error('Only demo accounts are permitted in this build.');
  const headers={'Authorization':'Bearer '+token,'Deriv-App-ID':appId};
  const otp=await fetch(`${API}/trading/v1/options/accounts/${encodeURIComponent(accountId)}/otp`,{method:'POST',headers});
  const oj=await otp.json();if(!otp.ok)throw Error(oj?.errors?.[0]?.message||'Could not obtain demo WebSocket session.');
  const url=oj?.data?.url;if(!url||!url.includes('/demo'))throw Error('Selected account is not a demo account. Live accounts are blocked.');
  const acct=await fetch(`${API}/trading/v1/options/accounts`,{headers});
  const aj=await acct.json();if(!acct.ok)throw Error(aj?.errors?.[0]?.message||'Could not read accounts.');
  const list=aj?.data||aj?.accounts||[];const found=list.find(x=>(x.account_id||x.id)===accountId);
  if(found&&String(found.account_type||'').toLowerCase()!=='demo')throw Error('Only demo accounts are allowed.');
  if(deriv)deriv.close();ticks=[];balance=null;currency='';
  deriv=new WebSocket(url);
  deriv.on('open',()=>{send({active_symbols:'brief',req_id:1});send({balance:1,subscribe:1,req_id:2});});
  deriv.on('message',raw=>{try{const d=JSON.parse(raw.toString());if(d.error){lastErr=d.error.message;return}
   if(d.msg_type==='active_symbols'){markets=(d.active_symbols||[]).filter(x=>/volatility|jump|step|boom|crash/i.test((x.display_name||'')+' '+(x.symbol||''))).map(x=>({symbol:x.symbol,display_name:x.display_name}));markets=markets.slice(0,40);markets.forEach((m,i)=>send({ticks:m.symbol,subscribe:1,req_id:100+i}));}
   if(d.msg_type==='tick'){const t=d.tick;if(t){const old=ticks.findIndex(x=>x.symbol===t.symbol);const item={symbol:t.symbol,quote:t.quote};if(old>=0)ticks[old]=item;else ticks.push(item);}}
   if(d.msg_type==='balance'){balance=d.balance?.balance;currency=d.balance?.currency||'';}
  }catch(e){lastErr=e.message}});
  deriv.on('error',e=>lastErr=e.message);deriv.on('close',()=>{lastErr='Deriv connection closed';});
  // wait briefly for websocket handshake and market list
  await new Promise(r=>setTimeout(r,1200));
  res.json({ok:true,balance,currency,markets});
 }catch(e){res.status(400).json({error:e.message})}
});
app.get('/api/status',(req,res)=>res.json({connected:!!deriv&&deriv.readyState===WebSocket.OPEN,balance,currency,markets,ticks,lastErr}));
app.post('/api/disconnect',(req,res)=>{if(deriv)deriv.close();deriv=null;ticks=[];markets=[];balance=null;res.json({ok:true})});
app.get('/health',(req,res)=>res.json({ok:true}));
const port=process.env.PORT||3000;app.listen(port,()=>console.log('ZEN TRADE AI running on '+port));
