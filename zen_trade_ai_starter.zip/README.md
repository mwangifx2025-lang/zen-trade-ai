# ZEN TRADE AI — Deriv live-data / paper-test starter

## What this build does
- Connects through Deriv's current REST OTP + WebSocket flow.
- Enforces a DEMO-only authenticated WebSocket URL.
- Streams live synthetic-market quotes and demo balance.
- Provides a browser dashboard and a simple paper-trading test loop.
- Does NOT send buy orders or trade real money.

The displayed paper P/L is an illustrative signal-test estimate, not a backtest, Deriv contract payout, or forecast. Do not treat it as evidence of profitability.

## Run locally
1. Install Node.js 20 or newer.
2. Unzip this folder.
3. In the folder run:
   `npm install`
   `npm start`
4. Open `http://localhost:3000`.
5. In Deriv's developer dashboard, register a NEW PAT application and create a token with the minimum read/trade scopes needed for demo access.
6. Enter the new App ID, PAT and your DEMO Options account ID in the dashboard.

Do not paste your token into chats or share it. This backend keeps it only for the duration of the OTP request; it does not save it to disk. Use a dedicated demo token and revoke it if exposed.

## 24/7 hosting
Local operation stops when your computer/server stops. To run while your phone is offline, deploy this Node service to an always-on VPS/cloud host with HTTPS, process supervision (systemd or equivalent), restricted access, and secret management. This starter is not yet a production unattended trading bot.

## Before live execution
A proper live system still needs a validated strategy, contract-specific proposal/payout handling, buy/open-contract monitoring, stop-loss enforcement, persistent audit logs, reconnect recovery, duplicate-order prevention, and server-side risk controls. This package intentionally does not implement real-money order execution.

## API references
- https://developers.deriv.com/docs/intro/api-overview/
- https://developers.deriv.com/docs/workflows/
- https://developers.deriv.com/docs/trading/proposal/
